package com.zefari.modules;

import com.zefari.module.Category;
import com.zefari.module.Module;
import com.zefari.setting.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.concurrent.ThreadLocalRandom;

public class Aura extends Module {
    public final Setting.Num reach = add(new Setting.Num("Reach", 3.0, 1, 8));
    public final Setting.Bool wallDetect = add(new Setting.Bool("Wall Detect", true));
    public final Setting.Num wallRange = add(new Setting.Num("Wall Range", 0, 0, 8));
    @SuppressWarnings("unused")
    private final Setting rotLabel = add(new Setting.Label("Rotations"));
    public final Setting.Bool track = add(new Setting.Bool("Track", true));
    public final Setting.Bool onlyWeapon = add(new Setting.Bool("Only Weapon", true));
    public final Setting.Num aimedPitchStep = add(new Setting.Num("AimedPitchStep", 15, 1, 90));
    public final Setting.Num maxPitchStep = add(new Setting.Num("MaxPitchStep", 40, 1, 90));
    public final Setting.Num minYawStep = add(new Setting.Num("MinYawStep", 20, 1, 180));
    public final Setting.Num maxYawStep = add(new Setting.Num("MaxYawStep", 70, 1, 180));
    public final Setting.Num pitchAccelerate = add(new Setting.Num("PitchAccelerate", 3, 1, 10));

    /** TargetESP bunu okur. */
    public LivingEntity target;
    private int accelTicks;

    public Aura() { super("Aura", Category.COMBAT); }

    @Override public void onDisable() { target = null; accelTicks = 0; }

    @Override
    public void onTick() {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null || mc.currentScreen != null || !p.isAlive()) {
            target = null; accelTicks = 0; return;
        }

        target = findTarget(p, w);
        if (target == null) { accelTicks = 0; return; }

        if (track.value) rotate(p, target);

        if (ElyHelper.isBusy()) return;                       // Ely Helper uyumu
        if (p.getAttackCooldownProgress(0.5f) < 0.95f) return;

        double dist = distTo(p, target);
        if (dist > reach.value) return;
        if (behindWall(p, target) && dist > wallRange.value) return; // wallRange 0 => duvar arkasi vurmaz
        if (track.value && !lookingAt(p, target)) return;

        if (onlyWeapon.value) equipWeapon(p);
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);
    }

    private LivingEntity findTarget(ClientPlayerEntity p, ClientWorld w) {
        LivingEntity best = null;
        double bestD = Double.MAX_VALUE;
        for (PlayerEntity o : w.getPlayers()) {
            if (o == p || !o.isAlive() || o.isSpectator()) continue;
            double d = distTo(p, o);
            if (d > reach.value) continue;
            if (wallDetect.value && behindWall(p, o)) continue;
            if (d < bestD) { bestD = d; best = o; }
        }
        return best;
    }

    private double distTo(ClientPlayerEntity p, LivingEntity t) {
        Box b = t.getBoundingBox();
        Vec3d e = p.getEyePos();
        double dx = MathHelper.clamp(e.x, b.minX, b.maxX) - e.x;
        double dy = MathHelper.clamp(e.y, b.minY, b.maxY) - e.y;
        double dz = MathHelper.clamp(e.z, b.minZ, b.maxZ) - e.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private boolean behindWall(ClientPlayerEntity p, LivingEntity t) {
        Vec3d e = p.getEyePos();
        Vec3d pt = new Vec3d(t.getX(), t.getY() + t.getHeight() * 0.6, t.getZ());
        HitResult r = mc.world.raycast(new RaycastContext(e, pt,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        return r.getType() == HitResult.Type.BLOCK;
    }

    private boolean lookingAt(ClientPlayerEntity p, LivingEntity t) {
        Vec3d e = p.getEyePos();
        Vec3d end = e.add(p.getRotationVec(1f).multiply(reach.value + 0.5));
        return t.getBoundingBox().expand(0.15).raycast(e, end).isPresent();
    }

    private void rotate(ClientPlayerEntity p, LivingEntity t) {
        Vec3d e = p.getEyePos();
        Box b = t.getBoundingBox();
        double ay = MathHelper.clamp(e.y, b.minY + 0.3, b.maxY - 0.2);
        double dx = t.getX() - e.x, dy = ay - e.y, dz = t.getZ() - e.z;
        float yawT = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitchT = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));

        float yawDiff = MathHelper.wrapDegrees(yawT - p.getYaw());
        float pitchDiff = pitchT - p.getPitch();

        accelTicks++;
        double prog = Math.min(1.0, accelTicks / pitchAccelerate.value);

        double lo = Math.min(minYawStep.value, maxYawStep.value);
        double hi = Math.max(minYawStep.value, maxYawStep.value);
        double yawStep = lo >= hi ? lo : ThreadLocalRandom.current().nextDouble(lo, hi);
        float yawMove = (float) Math.min(Math.abs(yawDiff), yawStep);

        double base = Math.abs(pitchDiff) < 5 ? aimedPitchStep.value : maxPitchStep.value;
        float pitchMove = (float) Math.min(Math.abs(pitchDiff), Math.max(0.5, base * prog));

        p.setYaw(p.getYaw() + Math.signum(yawDiff) * yawMove);
        p.setPitch(MathHelper.clamp(p.getPitch() + Math.signum(pitchDiff) * pitchMove, -90f, 90f));
    }

    private void equipWeapon(ClientPlayerEntity p) {
        PlayerInventory inv = p.getInventory();
        if (isWeapon(p.getMainHandStack())) return;
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() instanceof SwordItem) { inv.selectedSlot = i; return; }
        }
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() instanceof AxeItem) { inv.selectedSlot = i; return; }
        }
    }

    private boolean isWeapon(ItemStack s) {
        return s.getItem() instanceof SwordItem || s.getItem() instanceof AxeItem;
    }
}
