package com.zefari.modules;

import com.zefari.module.Category;
import com.zefari.module.Module;
import com.zefari.setting.Setting;
import com.zefari.util.Fx;

public class ClickGuiModule extends Module {
    public final Setting.Num hue = add(new Setting.Num("Hue", 0.75, 0, 1));
    public final Setting.Num sat = add(new Setting.Num("Saturation", 0.75, 0, 1));
    public final Setting.Num bri = add(new Setting.Num("Brightness", 1.0, 0, 1));

    public ClickGuiModule() {
        super("Click GUI", Category.CLIENT);
        enabled = true;
        add(new Setting.Swatch("Color", Fx::theme));
    }

    @Override public boolean canToggle() { return false; }
}
