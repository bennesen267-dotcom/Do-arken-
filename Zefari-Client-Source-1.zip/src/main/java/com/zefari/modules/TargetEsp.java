package com.zefari.modules;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.zefari.module.Category;
import com.zefari.module.Module;
import com.zefari.module.ModuleManager;
import com.zefari.setting.Setting;
import com.zefari.util.Fx;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;

public class TargetEsp extends Module {
    public final Setting.Mode mode = add(new Setting.Mode("Mode", "Ghost", "GhostV2", "Nurik"));

    public TargetEsp() { super("Target ESP", Category.RENDER); }

    @Override
    public void onWorldRender(MatrixStack ms, float td, Vec3d cam) {
        Aura aura = ModuleManager.aura;
        if (aura == null || !aura.enabled) return;
        LivingEntity t = aura.target;
        if (t == null || !t.isAlive()) return;

        double x = MathHelper.lerp(td, t.prevX, t.getX()) - cam.x;
        double y = MathHelper.lerp(td, t.prevY, t.getY()) - cam.y;
        double z = MathHelper.lerp(td, t.prevZ, t.getZ()) - cam.z;
        float h = t.getHeight();
        double r = t.getWidth() * 0.5 + 0.5;
        Matrix4f m = ms.peek().getPositionMatrix();
        int rgb = Fx.theme();
        double time = System.nanoTime() / 1.0e9;

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        switch (mode.get()) {
            case "Ghost" -> ghost(m, x, y, z, h, r, time, rgb);
            case "GhostV2" -> lines(m, x, y, z, h, r, time, rgb);
            default -> chains(m, x, y, z, h, r, time, rgb);
        }

        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
    }

    // ---------- Ghost: etrafinda donen parlak bulutlar ----------
    private void ghost(Matrix4f m, double x, double y, double z, float h, double r, double time, int rgb) {
        Camera cam = mc.gameRenderer.getCamera();
        Vector3f right = new Vector3f(1, 0, 0).rotate(cam.getRotation());
        Vector3f up = new Vector3f(0, 1, 0).rotate(cam.getRotation());
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        int n = 7, trail = 7;
        for (int i = 0; i < n; i++) {
            double base = i * Math.PI * 2 / n;
            for (int k = 0; k < trail; k++) {
                double tt = time - k * 0.045;
                double a = tt * 2.0 + base;
                double hy = h * 0.5 + Math.sin(tt * 1.4 + i * 1.3) * h * 0.42;
                float fade = 1f - k / (float) trail;
                glow(b, m, x + Math.cos(a) * r, y + hy, z + Math.sin(a) * r,
                        0.17f * (0.5f + fade * 0.5f), right, up, rgb, (int) (200 * fade * fade) + 10);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    private void glow(BufferBuilder b, Matrix4f m, double cx, double cy, double cz, float size,
                      Vector3f right, Vector3f up, int rgb, int alpha) {
        int R = (rgb >> 16) & 255, G = (rgb >> 8) & 255, B = rgb & 255;
        int seg = 10;
        for (int s = 0; s < seg; s++) {
            double a0 = Math.PI * 2 * s / seg, a1 = Math.PI * 2 * (s + 1) / seg;
            float x0 = (float) (cx + (right.x * Math.cos(a0) + up.x * Math.sin(a0)) * size);
            float y0 = (float) (cy + (right.y * Math.cos(a0) + up.y * Math.sin(a0)) * size);
            float z0 = (float) (cz + (right.z * Math.cos(a0) + up.z * Math.sin(a0)) * size);
            float x1 = (float) (cx + (right.x * Math.cos(a1) + up.x * Math.sin(a1)) * size);
            float y1 = (float) (cy + (right.y * Math.cos(a1) + up.y * Math.sin(a1)) * size);
            float z1 = (float) (cz + (right.z * Math.cos(a1) + up.z * Math.sin(a1)) * size);
            b.vertex(m, (float) cx, (float) cy, (float) cz).color(R, G, B, alpha);
            b.vertex(m, x0, y0, z0).color(R, G, B, 0);
            b.vertex(m, x1, y1, z1).color(R, G, B, 0);
        }
    }

    // ---------- GhostV2: 3 donen cizgi ----------
    private void lines(Matrix4f m, double x, double y, double z, float h, double r, double time, int rgb) {
        int R = (rgb >> 16) & 255, G = (rgb >> 8) & 255, B = rgb & 255;
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        int L = 30;
        for (int i = 0; i < 3; i++) {
            double phase = i * Math.PI * 2 / 3;
            double[] px = new double[L + 1], py = new double[L + 1], pz = new double[L + 1];
            for (int k = 0; k <= L; k++) {
                double a = time * 2.4 + phase - k * 0.065;
                double yy = h * 0.5 + Math.sin(time * 1.6 + phase - k * 0.04) * h * 0.45;
                px[k] = x + Math.cos(a) * r; py[k] = y + yy; pz[k] = z + Math.sin(a) * r;
            }
            for (int k = 0; k < L; k++) {
                double tx = px[k + 1] - px[k], ty = py[k + 1] - py[k], tz = pz[k + 1] - pz[k];
                // tangent x view (kamera orijinde) -> ekrana donuk kalinlik
                double ox = ty * pz[k] - tz * py[k];
                double oy = tz * px[k] - tx * pz[k];
                double oz = tx * py[k] - ty * px[k];
                double len = Math.sqrt(ox * ox + oy * oy + oz * oz);
                if (len < 1e-9) continue;
                double w = 0.022 / len;
                ox *= w; oy *= w; oz *= w;
                int a0 = (int) (230 * (1 - k / (double) L)), a1 = (int) (230 * (1 - (k + 1) / (double) L));
                b.vertex(m, (float) (px[k] + ox), (float) (py[k] + oy), (float) (pz[k] + oz)).color(R, G, B, a0);
                b.vertex(m, (float) (px[k] - ox), (float) (py[k] - oy), (float) (pz[k] - oz)).color(R, G, B, a0);
                b.vertex(m, (float) (px[k + 1] - ox), (float) (py[k + 1] - oy), (float) (pz[k + 1] - oz)).color(R, G, B, a1);
                b.vertex(m, (float) (px[k + 1] + ox), (float) (py[k + 1] + oy), (float) (pz[k + 1] + oz)).color(R, G, B, a1);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    // ---------- Nurik: 3 donen zincir ----------
    private void chains(Matrix4f m, double x, double y, double z, float h, double r, double time, int rgb) {
        BufferBuilder b = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        int links = 14;
        for (int c = 0; c < 3; c++) {
            double phase = c * Math.PI * 2 / 3;
            for (int k = 0; k < links; k++) {
                double a = time * 2.2 + phase - k * 0.19;
                double yy = h * 0.5 + Math.sin(time * 1.3 + phase - k * 0.07) * h * 0.3;
                double cx = x + Math.cos(a) * r, cy = y + yy, cz = z + Math.sin(a) * r;
                double[] T = {-Math.sin(a), 0, Math.cos(a)};
                double[] N = (k % 2 == 0) ? new double[]{0, 1, 0} : new double[]{Math.cos(a), 0, Math.sin(a)};
                int alpha = (int) (230 * (1 - k / (double) links) * 0.8 + 25);
                ring(b, m, cx, cy, cz, T, N, 0.085, 0.045, rgb, alpha);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    private void ring(BufferBuilder b, Matrix4f m, double cx, double cy, double cz, double[] T, double[] N,
                      double A, double Bw, int rgb, int alpha) {
        int R = (rgb >> 16) & 255, G = (rgb >> 8) & 255, B = rgb & 255;
        int seg = 10;
        for (int s = 0; s < seg; s++) {
            double a0 = Math.PI * 2 * s / seg, a1 = Math.PI * 2 * (s + 1) / seg;
            double c0 = Math.cos(a0) * A, s0 = Math.sin(a0) * Bw, c1 = Math.cos(a1) * A, s1 = Math.sin(a1) * Bw;
            double k = 0.62;
            vtx(b, m, cx + T[0] * c0 + N[0] * s0, cy + T[1] * c0 + N[1] * s0, cz + T[2] * c0 + N[2] * s0, R, G, B, alpha);
            vtx(b, m, cx + T[0] * c1 + N[0] * s1, cy + T[1] * c1 + N[1] * s1, cz + T[2] * c1 + N[2] * s1, R, G, B, alpha);
            vtx(b, m, cx + T[0] * c1 * k + N[0] * s1 * k, cy + T[1] * c1 * k + N[1] * s1 * k, cz + T[2] * c1 * k + N[2] * s1 * k, R, G, B, alpha);
            vtx(b, m, cx + T[0] * c0 * k + N[0] * s0 * k, cy + T[1] * c0 * k + N[1] * s0 * k, cz + T[2] * c0 * k + N[2] * s0 * k, R, G, B, alpha);
        }
    }

    private void vtx(BufferBuilder b, Matrix4f m, double x, double y, double z, int r, int g, int bl, int a) {
        b.vertex(m, (float) x, (float) y, (float) z).color(r, g, bl, a);
    }
}
