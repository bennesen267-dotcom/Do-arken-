package com.zefari.modules;

import com.zefari.module.Category;
import com.zefari.module.Module;
import com.zefari.setting.Setting;

/** Sadece elimizdeki item/el gorus acisini degistirir (GameRendererMixin). */
public class ItemFov extends Module {
    public final Setting.Num fov = add(new Setting.Num("FOV", 110, 30, 170));
    public ItemFov() { super("Item FOV", Category.RENDER); }
}
