package com.zefari.gui;

import com.zefari.module.Category;
import com.zefari.module.Module;
import com.zefari.module.ModuleManager;
import com.zefari.setting.Setting;
import com.zefari.util.Fx;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClickGuiScreen extends Screen {
    private static final int PW = 128, HEAD = 18, ROW = 13, GAP = 8;
    private static final int NEED_W = 5 * PW + 4 * GAP + 16;

    private record Hit(int x, int y, int w, int h, Module module, Setting setting) {
        boolean in(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final List<Hit> hits = new ArrayList<>();
    private Hit dragHit;
    private float scale = 1f;

    public ClickGuiScreen() { super(Text.literal("Zefari")); }

    @Override public boolean shouldPause() { return false; }

    // Vanilla blur/karartmayi kapat, kendi arka planimizi ciziyoruz
    @Override public void renderBackground(DrawContext c, int mx, int my, float d) {}

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        scale = Math.min(1f, width / (float) NEED_W);
        int vw = (int) (width / scale);
        double vmx = mx / scale, vmy = my / scale;

        ctx.fillGradient(0, 0, width, height, Fx.alpha(Fx.theme(), 70), 0xD0000000);
        hits.clear();

        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.scale(scale, scale, 1f);

        TextRenderer tr = textRenderer;
        String title = "ZEFARI";
        Fx.waveText(ctx, tr, title, (vw - tr.getWidth(title)) / 2, 9);

        if (dragHit != null && dragHit.setting() instanceof Setting.Num n) {
            n.setFromRatio((vmx - (dragHit.x() + 4)) / (double) (dragHit.w() - 8));
        }

        Category[] cats = Category.values();
        int x0 = (vw - (cats.length * PW + (cats.length - 1) * GAP)) / 2;
        for (int i = 0; i < cats.length; i++) panel(ctx, cats[i], x0 + i * (PW + GAP), 26, vmx, vmy);

        String hint = "Left click: toggle  |  Right click: settings  |  RShift: close";
        ctx.drawText(tr, hint, (vw - tr.getWidth(hint)) / 2, (int) (height / scale) - 12, 0xFF8888A0, false);
        ms.pop();
    }

    private void panel(DrawContext ctx, Category cat, int x, int y0, double mx, double my) {
        TextRenderer tr = textRenderer;
        int y = y0;
        ctx.fill(x, y, x + PW, y + HEAD, 0xE60E0E16);
        Fx.sweep(ctx, x, y, PW, 2, 255);
        ctx.drawText(tr, cat.label, x + 6, y + 7, 0xFFFFFFFF, true);
        y += HEAD;

        List<Module> mods = ModuleManager.in(cat);
        if (mods.isEmpty()) {
            ctx.fill(x, y, x + PW, y + ROW, 0xC0141420);
            ctx.drawText(tr, "(empty)", x + 6, y + 3, 0xFF707080, false);
            y += ROW;
        }
        for (Module m : mods) {
            boolean hov = mx >= x && mx < x + PW && my >= y && my < y + ROW;
            ctx.fill(x, y, x + PW, y + ROW, hov ? 0xD01C1C2A : 0xC0141420);
            if (m.enabled) {
                Fx.sweep(ctx, x, y, PW, ROW, 95);
                ctx.fill(x, y, x + 2, y + ROW, Fx.alpha(Fx.theme(), 255));
            }
            ctx.drawText(tr, m.name, x + 6, y + 3, m.enabled ? 0xFFFFFFFF : 0xFFB0B0C0, true);
            if (!m.settings.isEmpty()) ctx.drawText(tr, m.expanded ? "-" : "+", x + PW - 10, y + 3, 0xFF909098, false);
            hits.add(new Hit(x, y, PW, ROW, m, null));
            y += ROW;
            if (m.expanded) for (Setting s : m.settings) y = setting(ctx, m, s, x, y);
        }
        Fx.sweep(ctx, x, y, PW, 2, 255);
        Fx.glow(ctx, x, y0, PW, y + 2 - y0);
    }

    private int setting(DrawContext ctx, Module m, Setting s, int x, int y) {
        TextRenderer tr = textRenderer;
        int h = ROW;
        ctx.fill(x, y, x + PW, y + h, 0xC00B0B12);
        int theme = Fx.theme();

        if (s instanceof Setting.Label l) {
            ctx.fill(x + 4, y + h / 2, x + 8, y + h / 2 + 1, 0xFF50506A);
            ctx.drawText(tr, l.name, x + 12, y + 3, 0xFF8888AA, false);
            return y + h;
        }
        if (s instanceof Setting.Bool b) {
            ctx.drawText(tr, b.name, x + 8, y + 3, 0xFFD0D0E0, false);
            ctx.fill(x + PW - 18, y + 3, x + PW - 6, y + h - 3, b.value ? Fx.alpha(theme, 255) : 0xFF2A2A36);
        } else if (s instanceof Setting.Num n) {
            int filled = (int) ((PW - 8) * n.ratio());
            ctx.fill(x + 4, y + 1, x + 4 + filled, y + h - 1, Fx.alpha(theme, 110));
            ctx.fill(x + 4 + filled - 1, y + 1, x + 4 + filled + 1, y + h - 1, Fx.alpha(theme, 255));
            String v = String.format(Locale.ROOT, "%.2f", n.value);
            ctx.drawText(tr, n.name, x + 8, y + 3, 0xFFD0D0E0, false);
            ctx.drawText(tr, v, x + PW - 8 - tr.getWidth(v), y + 3, 0xFFFFFFFF, false);
        } else if (s instanceof Setting.Mode md) {
            ctx.drawText(tr, md.name + ":", x + 8, y + 3, 0xFFD0D0E0, false);
            ctx.drawText(tr, md.get(), x + PW - 8 - tr.getWidth(md.get()), y + 3, Fx.alpha(theme, 255), false);
        } else if (s instanceof Setting.Swatch sw) {
            ctx.drawText(tr, sw.name, x + 8, y + 3, 0xFFD0D0E0, false);
            ctx.fill(x + PW - 34, y + 3, x + PW - 6, y + h - 3, 0xFF000000 | sw.color.getAsInt());
        }
        hits.add(new Hit(x, y, PW, h, m, s));
        return y + h;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        double vx = mx / scale, vy = my / scale;
        for (Hit h : hits) {
            if (!h.in(vx, vy)) continue;
            Setting s = h.setting();
            if (s == null) {
                Module m = h.module();
                if (button == 0 && m.canToggle()) m.toggle();
                else if (button == 1) m.expanded = !m.expanded;
            } else if (s instanceof Setting.Bool b) {
                if (button == 0) b.toggle();
            } else if (s instanceof Setting.Mode md) {
                if (button == 0) md.next(); else if (button == 1) md.prev();
            } else if (s instanceof Setting.Num) {
                if (button == 0) dragHit = h;
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        dragHit = null;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
}
