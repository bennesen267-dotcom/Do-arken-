# Zefari (Fabric 1.21.1)

Derleme: repoyu GitHub'a yukle -> Actions sekmesi -> "build" -> Artifacts -> Zefari (jar).
Yerelde: `gradle build` (Java 21, Gradle 8.10+). Jar: build/libs/zefari-1.0.0.jar
Gerekli: Fabric Loader 0.16+, Fabric API 0.102.0+1.21.1
Menu: Right Shift.
